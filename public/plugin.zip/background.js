
chrome.runtime.onMessage.addListener((msg, sender) => {
  
  
  //alert(msg.total_elements)
  $.ajax({
  
	url:'http://qrcodes.local/sync-data',
	method:'post',
	data:{elements:msg.total_elements},
	success:function(){
		    //localStorage.removeItem('data');
			alert('Page Data Has Been Synced. Please Go to Next Page')
		},
	error:function(){
			alert('Data Syncing is Not Successfull')
		}	
  
  })
  //alert(msg.total_elements)
});
