
var datas=[]

$(document).ready(function(){
		
		$("#changeColor").click(function(){
			
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
			  chrome.tabs.executeScript(
				  tabs[0].id,
				  {code: '('+getDataFROMDOM+')();'}
				  );
			});

			//~ datas=localStorage.getItem('data')
			//~ alert(datas)
			
			//~ console.log(JSON.stringify(datas))		
			
		});
			
});


function getDataFROMDOM(){
	datas=[]
	localStorage.removeItem('data')
	for(i=0;i<=10;i++){
		if(i<8){
			index='0'+(i+2)
		}else{
			index=(i+2)
		}
		certificate=document.getElementById("ctl00_default_gvSearchForm_ctl"+index+"_lblCertificateNumber")
		if(certificate!=null)
			certificate=certificate.innerHTML
		product=document.getElementById("ctl00_default_gvSearchForm_ctl"+index+"_lblProductName")
	    if(product!=null)
			product=product.innerHTML
	    
		if(certificate!=null && product!=null){
			datas[i]={'product':product, 'certificate':certificate}	
		}		
	}
	
	datas=JSON.stringify(datas)
	chrome.runtime.sendMessage({
				total_elements: datas // or whatever you want to send
			});

	
	//~ alert(datas)
	//~ datas=JSON.stringify(datas)
	//~ alert(datas)
	//~ localStorage.setItem('data',datas);
}			
			
